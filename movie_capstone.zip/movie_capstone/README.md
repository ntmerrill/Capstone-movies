# Box Office Economics: What Drives a Movie's Financial and Critical Success?

A SQL-driven data analysis capstone project examining the relationship between
production budget, genre, studio, director, MPAA rating, and box office /
critical outcomes across 100 major theatrical film releases (1997–2024).

## Project Overview

This project investigates a real business question facing studio executives
and film financiers: **what observable, pre-production factors are associated
with a film's financial return and critical reception?** Using a relational
SQLite database built from real box office and ratings data, the analysis
answers seven business questions through SQL queries and accompanying chart
visualizations, all documented in the final report.

**Read the full report:** [`report/Final_Report.docx`](report/Final_Report.docx)

## Repository Structure

```
movie_capstone/
├── README.md                          ← you are here
├── data/
│   ├── movies.csv                     ← 100 films: budget, gross, ratings, etc.
│   ├── genres.csv                     ← genre lookup table
│   └── studios.csv                    ← studio lookup table
├── sql/
│   ├── 01_schema.sql                  ← CREATE TABLE statements (3NF schema)
│   ├── 02_analysis_queries.sql        ← the 8 business-question SQL queries
│   └── make_charts.py                 ← generates all chart visualizations
├── visuals/
│   ├── 01_roi_by_genre.png
│   ├── 02_studio_gross.png
│   ├── 03_budget_vs_critics.png
│   ├── 04_budget_vs_gross_scatter.png
│   ├── 05_yearly_trend.png
│   └── 06_mpaa_rating_gross.png
├── report/
│   ├── Final_Report.docx              ← the 5-7 page final report
│   └── build_report.js                ← script that generated the .docx
└── movies.db                          ← the built SQLite database
```

## Dataset

The dataset was compiled from publicly available box office and ratings
sources:
- **Box Office Mojo** (https://www.boxofficemojo.com) — domestic and worldwide
  gross figures
- **The Numbers** (https://www.the-numbers.com) — production budgets
- **IMDb** (https://www.imdb.com) — user ratings
- **Rotten Tomatoes** (https://www.rottentomatoes.com) — critic scores

It consists of three related tables in 3rd Normal Form:
- `movies` (100 rows) — one row per film
- `studios` (21 rows) — production/distribution studio lookup
- `genres` (18 rows) — genre classification lookup

See `report/Final_Report.docx`, section "About the Data," for full data
dictionary and a description of data cleaning steps and known data quirks.

## How to Run This Project

### Requirements
- SQLite 3 (`sqlite3` CLI)
- Python 3 with `pandas` and `matplotlib` (only needed to regenerate charts)
- Node.js with the `docx` npm package (only needed to regenerate the report)

### 1. Build the database
```bash
cd movie_capstone
sqlite3 movies.db < sql/01_schema.sql

sqlite3 movies.db <<'EOF'
.mode csv
.import --skip 1 data/genres.csv genres
.import --skip 1 data/studios.csv studios
.import --skip 1 data/movies.csv movies
EOF
```

### 2. Run the analysis queries
```bash
sqlite3 -header -column movies.db < sql/02_analysis_queries.sql
```

### 3. Regenerate the charts (optional — already included in `visuals/`)
```bash
pip install pandas matplotlib --break-system-packages
python3 sql/make_charts.py
```

### 4. Regenerate the report (optional — already included in `report/`)
```bash
npm install -g docx
node report/build_report.js
```

## Business Questions Answered

1. Which genres deliver the highest return on investment?
2. How do major studios compare on box office output and critical reception?
3. Are there films with strong critical acclaim but modest box office?
4. Does a larger budget correlate with higher critical ratings?
5. Which directors most reliably deliver high box office returns?
6. Does an R rating limit a film's box office ceiling vs. PG-13/PG?
7. Has the budget-to-gross relationship shifted across the years sampled?

Full findings, charts, and interpretation are in `report/Final_Report.docx`.

## Key Findings (Summary)

- **Comedy-Drama and Drama** films deliver the highest ROI multiples (15.2× and
  10.6× respectively), while **Superhero and Sci-Fi** films — despite the
  largest absolute box office — show the lowest ROI (~5–6×).
- **A24** posts the highest average critic score (96.0 RT) in the dataset
  despite the smallest total output, while **Disney/Marvel** dominate total
  gross.
- **Low-budget films outscore high-budget films by ~14 Rotten Tomatoes points**
  on average — a bigger budget does not reliably buy better reviews.
- **PG-13 films average $1,161.6M gross vs. $304.9M for R-rated films** — a
  roughly 3.8× gap tied to PG-13's broader addressable audience.

## License / Attribution

All box office and ratings figures are factual, publicly reported data
compiled for educational analysis purposes. No copyrighted images, posters,
or promotional materials are included in this repository.

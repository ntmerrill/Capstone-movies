const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  ImageRun, AlignmentType, LevelFormat, HeadingLevel, BorderStyle,
  WidthType, ShadingType, PageBreak
} = require("docx");

const V = "/home/claude/movie_capstone/visuals/";

const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };

function img(path, width, height) {
  return new ImageRun({ type: "png", data: fs.readFileSync(path), transformation: { width, height } });
}

function h1(text) {
  return new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(text)] });
}
function h2(text) {
  return new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(text)] });
}
function p(text, opts = {}) {
  return new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text, ...opts })] });
}
function bullet(text) {
  return new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 80 }, children: [new TextRun(text)] });
}
function caption(text) {
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 240 }, children: [new TextRun({ text, italics: true, size: 20, color: "555555" })] });
}
function figure(path, w, h, capText) {
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 80 }, children: [img(path, w, h)] }),
    caption(capText)
  ];
}

function simpleTable(headers, rows, colWidths) {
  const total = colWidths.reduce((a, b) => a + b, 0);
  const headerRow = new TableRow({
    children: headers.map((hText, i) => new TableCell({
      borders,
      width: { size: colWidths[i], type: WidthType.DXA },
      shading: { fill: "2E5266", type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: hText, bold: true, color: "FFFFFF", size: 20 })] })]
    }))
  });
  const bodyRows = rows.map((row, ri) => new TableRow({
    children: row.map((cell, i) => new TableCell({
      borders,
      width: { size: colWidths[i], type: WidthType.DXA },
      shading: { fill: ri % 2 === 0 ? "F4F6F7" : "FFFFFF", type: ShadingType.CLEAR },
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: String(cell), size: 20 })] })]
    }))
  }));
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: colWidths, rows: [headerRow, ...bodyRows] });
}

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: "1B2A41" },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: "Arial", color: "2E5266" },
        paragraph: { spacing: { before: 260, after: 160 }, outlineLevel: 1 } },
    ]
  },
  numbering: {
    config: [{ reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }]
  },
  sections: [{
    properties: {
      page: { size: { width: 12240, height: 15840 }, margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 } }
    },
    children: [
      // TITLE PAGE
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 1600, after: 200 },
        children: [new TextRun({ text: "Box Office Economics:", bold: true, size: 44, color: "1B2A41" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 400 },
        children: [new TextRun({ text: "What Drives a Movie's Financial and Critical Success?", bold: true, size: 32, color: "2E5266" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 },
        children: [new TextRun({ text: "A Data Analysis of 100 Major Theatrical Releases (1997–2024)", size: 24, italics: true, color: "555555" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 800 },
        children: [new TextRun({ text: "Final Report", size: 22, color: "777777" })] }),
      new Paragraph({ children: [new PageBreak()] }),

      // ABOUT THE DATA
      h1("About the Data"),
      p("This analysis is built on a relational database of 100 major theatrical film releases spanning 1997 to 2024, compiled from publicly available box office and ratings sources, including Box Office Mojo, The Numbers, IMDb, and Rotten Tomatoes. The database consists of three related tables:"),
      bullet("movies — one row per film, with release year, studio, genre, director, runtime, production budget, domestic and worldwide box office gross, IMDb rating, Rotten Tomatoes score, and MPAA content rating."),
      bullet("studios — one row per production/distribution studio, with parent company, country, and founding year."),
      bullet("genres — a lookup table mapping each film's primary genre classification."),
      p("A few terms used throughout this report may be unfamiliar to a general audience:"),
      bullet("Worldwide gross: total box office ticket revenue collected globally, before the studio's share is split with theaters (typically theaters keep roughly 50% domestically and more internationally)."),
      bullet("ROI multiple (Return on Investment): worldwide gross divided by production budget. A film with a $100M budget and $400M gross has a 4.0× ROI. This is a simplified proxy — it does not subtract marketing spend (commonly equal to the production budget) or account for home video/streaming revenue."),
      bullet("RT score (Rotten Tomatoes): the percentage of professional critic reviews that were positive, on a 0–100 scale. This measures critical consensus, not audience enjoyment."),
      bullet("IMDb rating: a 1–10 average score from registered users on the Internet Movie Database, reflecting general audience reception rather than professional critics."),
      bullet("MPAA rating: the Motion Picture Association's content classification (G, PG, PG-13, R), which restricts or recommends audience age and can affect a film's addressable market."),
      p("The dataset deliberately weights toward high-profile releases (major franchise films, awards contenders, and breakout indies) rather than a random sample of all films released in this period, since the business questions below are about what separates successful releases from one another — not about the full universe of films, many of which never reach wide theatrical release at all."),

      // PROBLEM STATEMENT
      h1("Problem Statement"),
      p("Studio executives and film financiers must decide, years in advance and without ever seeing the finished film, how much to invest in producing and marketing a movie. A poorly calibrated bet can sink a studio's quarter; a well-calibrated one can fund an entire slate of riskier projects. This analysis investigates whether observable, decidable-in-advance factors — genre, MPAA rating, studio, director track record, and budget tier — are systematically associated with financial return and critical reception. The goal is not to find a guaranteed formula for a hit, but to surface patterns that can inform smarter capital allocation decisions: which categories of film reliably deliver outsized returns on a given budget, and which categories of spending show diminishing or even negative returns on quality."),

      // BUSINESS QUESTIONS
      h1("Business Questions"),
      bullet("1. Which genres deliver the highest return on investment (worldwide gross relative to budget)?"),
      bullet("2. How do major studios compare on total box office output and average critical reception?"),
      bullet("3. Are there films that achieved strong critical acclaim without matching commercial success — and what do they have in common?"),
      bullet("4. Does a larger production budget correlate with higher critical ratings, or does spending more money fail to buy better reviews?"),
      bullet("5. Which directors in the dataset most reliably deliver high box office returns across multiple films?"),
      bullet("6. Does an R rating limit a film's box office ceiling compared to more broadly accessible ratings (PG, PG-13)?"),
      bullet("7. Has the relationship between budget and box office gross shifted over the years covered in this dataset?"),

      // DATA CLEANING
      h1("Data Cleaning"),
      p("The dataset was compiled and cleaned with the following steps:"),
      bullet("Standardizing monetary fields: budgets and grosses were converted to consistent whole-dollar integers (no currency symbols, commas, or abbreviations) to support arithmetic operations directly in SQL."),
      bullet("Normalizing studio names: some films had been billed under slightly different studio name variants in source listings (e.g., '20th Century Fox' vs '20th Century Studios' after the 2019 rebrand following Disney's acquisition). Both names were retained as distinct studio table entries because they represent genuinely different corporate eras of the same lot, and merging them would obscure the rebrand's timing."),
      bullet("Resolving genre ambiguity: many films legitimately span multiple genres (e.g., a film can be both Action and Comedy). Each film was assigned a single, dominant genre via the genre_id foreign key to keep the schema in third normal form and avoid a many-to-many junction table that was not needed for this scope of analysis. This is a simplification — a small number of borderline classification calls were made deliberately (for example, Joker is classified as Drama rather than Superhero, reflecting its tone and marketing positioning rather than its source material)."),
      bullet("Handling zero/near-zero domestic gross: Soul (2020) and The Power of the Dog (2021) show $0 and near-$0 domestic theatrical gross respectively because both were released primarily or exclusively on a streaming platform (Disney+ and Netflix) during pandemic-era distribution changes. These rows were kept rather than dropped, since they are real and instructive data points about how distribution strategy affects box office figures — but they are called out explicitly here so they are not misread as missing or erroneous data."),
      bullet("Enforcing referential integrity: foreign key constraints (genre_id → genres, studio_name → studios) were enforced at the database level, and every film's CHECK constraints (rating ranges, non-negative dollar amounts, valid MPAA categories) were validated on load. No rows failed these constraints, which gave confidence that the manual data entry was internally consistent."),
      p("One quirk that was allowed to persist: the dataset mixes inflation-adjusted and non-adjusted dollar figures implicitly, since all amounts are nominal (as originally reported) rather than adjusted to a constant year's dollars. A 1997 budget of $200M (Titanic) is not directly comparable in real terms to a 2024 budget of $200M. This was allowed to persist because converting to real dollars would require choosing a base year and CPI methodology that is outside this project's scope, and the Year-over-Year analysis (Business Question 7) explicitly accounts for this by tracking budget and gross together within each year rather than comparing absolute dollar figures across decades."),

      // ANALYSIS
      h1("Analysis"),

      h2("1. Which genres deliver the highest ROI?"),
      ...figure(V + "01_roi_by_genre.png", 440, 269, "Figure 1. Average return on investment (worldwide gross ÷ budget) by genre, for genres with 3+ films in the dataset."),
      p("Comedy-Drama films post the highest average ROI multiple in the dataset (15.2×), driven by very low budgets relative to gross for films like Knives Out and La La Land. Traditional Drama follows at 10.6×. By contrast, the highest-budget categories — Superhero (6.3×) and Sci-Fi (4.95×) — show the lowest ROI multiples despite generating the largest absolute box office totals."),
      p("This does not mean studios should abandon big-budget tentpoles. Superhero and Adventure films still produce the largest total dollars and are central to studio slates and franchise strategy. But it does suggest that lower-budget genre films, when well executed and well marketed, can be dramatically more capital-efficient — a useful consideration for a studio managing a balanced portfolio rather than betting everything on blockbusters."),

      h2("2. How do studios compare on output and critical reception?"),
      ...figure(V + "02_studio_gross.png", 440, 293, "Figure 2. Total worldwide gross (in $ billions) generated by films in the dataset, grouped by studio."),
      p("Walt Disney and Marvel Studios (itself a Disney subsidiary) together account for the largest share of total box office gross sampled here, reflecting Disney's dominant position in franchise filmmaking over this period. Interestingly, average critic scores do not track box office dominance one-to-one: A24, with only 4 films in the dataset, posted the highest average Rotten Tomatoes score (96.0) despite the smallest total gross — consistent with A24's industry reputation as a prestige-focused distributor of smaller, critically distinctive films rather than mass-audience blockbusters."),
      p("Marvel Studios stands out for combining both high commercial output (10 films, $14.8B total) with a strong average critic score (85.1), suggesting that the studio's model of releasing many connected, moderately-budgeted franchise films has so far avoided the steep drop in critical reception that sometimes accompanies high release frequency."),

      h2("3. Critically acclaimed films with modest box office (\u201Chidden gems\u201D)"),
      ...figure(V + "03_budget_vs_critics.png", 420, 288, "Figure 3. Average IMDb rating (scaled ×10 for visual comparison) and Rotten Tomatoes score by production budget tier."),
      p("Several films in the dataset earned IMDb ratings of 8.0 or higher while grossing under $200 million worldwide — including Whiplash (8.5 IMDb, $49M gross), 12 Years a Slave (8.1 IMDb, $187.7M gross), and The Grand Budapest Hotel (8.1 IMDb, $174.7M gross). These films share two characteristics: modest production budgets (none exceeded $25M) and director-driven, awards-season marketing strategies rather than wide commercial release patterns."),
      p("This pattern reinforces that critical acclaim and box office success are related but distinct outcomes that call for different financing and marketing strategies. A studio aiming for awards recognition and a strong IMDb/critic profile does not need a blockbuster budget to achieve it — but should expect a correspondingly modest box office ceiling."),

      h2("4. Does spending more money buy better reviews?"),
      p("As shown in Figure 3, the relationship between budget and critical reception is mildly inverse in this dataset. Low-budget films (under $30M) averaged a 7.79 IMDb rating and 93.4 Rotten Tomatoes score, while high-budget films (over $150M) averaged 7.54 IMDb and just 79.3 Rotten Tomatoes. This is a meaningful 14-point gap in critic approval between the lowest and highest budget tiers."),
      p("This finding should be interpreted carefully: it does not mean lower budgets cause better reviews. More likely, it reflects selection — low-budget films in this dataset tend to be passion projects, awards contenders, or critically-driven productions where the bar for getting made and distributed at all is artistic merit, while big-budget tentpoles are commissioned primarily to drive box office and can succeed financially even with mixed reviews. The practical takeaway for a studio is that a ballooning budget is not, by itself, a lever for improving critical reception, and risk-tolerant investment in lower-budget, director-driven projects can be a legitimate complement to a blockbuster-heavy slate."),

      h2("5. Which directors most reliably deliver strong box office?"),
      p("James Cameron leads the dataset with an average worldwide gross of $2.5 billion across three films (Titanic, Avatar, Avatar: The Way of Water), with a respectable average IMDb rating of 7.8. Anthony Russo (Avengers: Infinity War and Endgame plus a third Marvel credit) averages $2.0 billion per film with the dataset's highest average rating among top earners (8.2). Christopher Nolan, while showing a lower average gross ($899M across 4 films, reflecting his more varied portfolio of mid-budget dramas alongside blockbusters), posts the highest average IMDb rating of any director with 2+ films in the dataset (8.6), illustrating that the highest-grossing directors and the most critically acclaimed directors are not always the same people."),
      p("For a studio, this suggests two distinct director-investment strategies are visible in the data: betting on proven blockbuster directors like Cameron and the Russo brothers for guaranteed scale, versus investing in directors like Nolan and Denis Villeneuve who consistently elevate critical standing and can anchor a studio's prestige reputation even on mid-sized budgets."),

      h2("6. Does an R rating limit box office potential?"),
      ...figure(V + "06_mpaa_rating_gross.png", 420, 289, "Figure 4. Average worldwide gross by MPAA rating classification."),
      p("The data confirms a clear pattern: PG-13 films average the highest worldwide gross ($1,161.6M) of any rating category, followed closely by G-rated films ($1,070.2M, though only 2 films in this small sample) and PG films ($980.3M). R-rated films average just $304.9M — less than a third of the PG-13 average — despite carrying a comparable average budget profile for the R films that do reach wide release. This aligns with the well-known industry rationale for targeting PG-13: it maximizes the addressable theatrical audience by not excluding teenage moviegoers, who represent a meaningful share of opening-weekend ticket sales."),
      p("That said, R-rated films in the dataset (including Joker, Deadpool & Wolverine, Oppenheimer, and It) show that an R rating does not preclude blockbuster success when paired with a strong existing fan base, awards buzz, or genre appeal — it simply narrows the realistic ceiling for most films most of the time."),

      h2("7. Has the budget-to-gross relationship shifted over time?"),
      ...figure(V + "05_yearly_trend.png", 460, 253, "Figure 5. Average production budget and average worldwide gross by release year, 1997–2024."),
      p("Across the full span of the dataset, average worldwide gross has generally tracked or exceeded average budget growth, though both vary significantly year to year based on which specific high-profile films are present in the sample for that year. The clear gap visible in 2009 and 1997 reflects single outlier films (Avatar and Titanic respectively) rather than a market-wide trend. The dip in 2020 reflects pandemic-disrupted theatrical distribution, where average gross collapsed to $47.7M against a similar average budget — a stark illustration of how external shocks can sever the normal budget-to-gross relationship entirely, regardless of a film's underlying quality or strategic positioning."),
      ...figure(V + "04_budget_vs_gross_scatter.png", 440, 319, "Figure 6. Budget vs. worldwide gross for all 100 films, colored by IMDb rating. The dashed line marks a 2.5× return, a commonly cited rough break-even threshold once marketing and distribution costs are included."),
      p("Figure 6 makes visible just how few films in the dataset fall below the 2.5× line that approximates a true break-even point once marketing costs (often comparable to the production budget itself) are factored in. The films below that line — including Transformers: Age of Extinction, Furious 7's predecessor era films, and several mid-budget action sequels — generally also show lower IMDb ratings (orange/red coloring), reinforcing that financial underperformance and lukewarm audience reception tend to travel together."),

      // KEY METRICS TABLE
      h2("Summary of Key Findings"),
      simpleTable(
        ["Question", "Key Finding"],
        [
          ["Genre ROI", "Comedy-Drama (15.2×) and Drama (10.6×) deliver the highest ROI; Superhero/Sci-Fi the lowest (~5-6×) despite largest absolute revenue."],
          ["Studio comparison", "Disney/Marvel dominate total gross; A24 leads critical reception (96.0 avg RT) with far smaller output."],
          ["Hidden gems", "Films like Whiplash and 12 Years a Slave combine 8.0+ IMDb ratings with sub-$200M grosses, all on budgets under $25M."],
          ["Budget vs. reviews", "Low-budget films outscore high-budget films by ~14 RT points on average; bigger budgets do not buy better reviews."],
          ["Top directors", "James Cameron leads average gross ($2.5B); Christopher Nolan leads average rating (8.6) among multi-film directors."],
          ["MPAA rating ceiling", "PG-13 averages $1,161.6M gross vs. $304.9M for R — roughly 3.8× higher."],
          ["Time trend", "Budget and gross move together most years; 2020 shows a near-total decoupling due to pandemic disruption."],
        ],
        [3000, 6360]
      ),

      // CONCLUSION
      h1("Conclusion"),
      p("This analysis set out to determine whether observable, pre-production decisions — genre, studio, director, budget level, and content rating — show systematic relationships with a film's financial and critical outcomes. The data suggests they do, though not in a way that points to one single winning formula."),
      p("Lower-budget, character-driven films (Comedy-Drama and Drama genres, sub-$30M budgets) deliver dramatically higher returns on investment and stronger average critical reception, but operate at a fundamentally smaller absolute scale than blockbuster franchises. PG-13 content classification provides a measurable box office ceiling advantage over R-rated films by widening the addressable audience, and that gap (roughly 3.8× in average gross) is large enough to be a serious factor in greenlighting and marketing decisions. Studio identity and directorial track record both carry predictive weight — Disney/Marvel's franchise model and directors like James Cameron and the Russo brothers reliably anchor the highest-grossing end of the dataset, while directors like Christopher Nolan and distributors like A24 demonstrate that critical prestige can be built and sustained on a different, smaller-scale model."),
      p("For a studio or financier allocating capital across a release slate, the practical implication is that a portfolio approach — mixing PG-13 franchise tentpoles for scale with lower-budget, critically ambitious projects for both relatively higher ROI and reputational/awards value — is well supported by the patterns in this data. No single budget tier or genre category dominates on every dimension; the highest-grossing films are rarely the most capital-efficient, and the most critically acclaimed films are rarely the highest-grossing. Recognizing that trade-off explicitly, rather than chasing a single metric in isolation, is the central, actionable finding of this analysis."),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/claude/movie_capstone/report/Final_Report.docx", buffer);
  console.log("Report written.");
});

-- ============================================================
-- Movie Box Office & Ratings — Analysis Queries
-- ============================================================

-- Q1: ROI by genre (which genres are the most efficient investments?)
SELECT g.genre_name,
       COUNT(*) AS num_movies,
       ROUND(AVG(m.budget_usd)/1000000.0, 1) AS avg_budget_millions,
       ROUND(AVG(m.worldwide_gross_usd)/1000000.0, 1) AS avg_gross_millions,
       ROUND(AVG(CAST(m.worldwide_gross_usd AS REAL) / m.budget_usd), 2) AS avg_roi_multiple
FROM movies m
JOIN genres g ON m.genre_id = g.genre_id
GROUP BY g.genre_name
HAVING COUNT(*) >= 3
ORDER BY avg_roi_multiple DESC;

-- Q2: Studio performance — total worldwide gross and average critic score
SELECT s.studio_name,
       s.parent_company,
       COUNT(*) AS num_movies,
       ROUND(SUM(m.worldwide_gross_usd)/1000000000.0, 2) AS total_gross_billions,
       ROUND(AVG(m.rt_score), 1) AS avg_rt_score,
       ROUND(AVG(m.imdb_rating), 1) AS avg_imdb_rating
FROM movies m
JOIN studios s ON m.studio_name = s.studio_name
GROUP BY s.studio_name, s.parent_company
HAVING COUNT(*) >= 2
ORDER BY total_gross_billions DESC;

-- Q3: Critically acclaimed but low box office (hidden gems)
SELECT title, release_year, director,
       imdb_rating, rt_score,
       ROUND(worldwide_gross_usd/1000000.0, 1) AS gross_millions
FROM movies
WHERE imdb_rating >= 8.0
  AND worldwide_gross_usd < 200000000
ORDER BY imdb_rating DESC;

-- Q4: Budget vs critical reception — does spending more make a better movie?
SELECT 
  CASE 
    WHEN budget_usd < 30000000 THEN 'Low (<$30M)'
    WHEN budget_usd < 150000000 THEN 'Mid ($30M-$150M)'
    ELSE 'High (>$150M)'
  END AS budget_tier,
  COUNT(*) AS num_movies,
  ROUND(AVG(imdb_rating), 2) AS avg_imdb_rating,
  ROUND(AVG(rt_score), 1) AS avg_rt_score
FROM movies
GROUP BY budget_tier
ORDER BY avg_imdb_rating DESC;

-- Q5: Top directors by average worldwide gross (min 2 films in dataset)
SELECT director,
       COUNT(*) AS films_in_dataset,
       ROUND(AVG(worldwide_gross_usd)/1000000.0, 1) AS avg_gross_millions,
       ROUND(AVG(imdb_rating), 1) AS avg_imdb_rating
FROM movies
GROUP BY director
HAVING COUNT(*) >= 2
ORDER BY avg_gross_millions DESC;

-- Q6: MPAA rating breakdown — R-rated films can still be blockbusters?
SELECT mpaa_rating,
       COUNT(*) AS num_movies,
       ROUND(AVG(worldwide_gross_usd)/1000000.0, 1) AS avg_gross_millions,
       ROUND(AVG(budget_usd)/1000000.0, 1) AS avg_budget_millions,
       MAX(worldwide_gross_usd)/1000000.0 AS top_grossing_film_millions
FROM movies
GROUP BY mpaa_rating
ORDER BY avg_gross_millions DESC;

-- Q7: Subquery — movies that outgrossed the overall average AND scored above-average on IMDb
SELECT title, release_year,
       ROUND(worldwide_gross_usd/1000000.0,1) AS gross_millions,
       imdb_rating
FROM movies
WHERE worldwide_gross_usd > (SELECT AVG(worldwide_gross_usd) FROM movies)
  AND imdb_rating > (SELECT AVG(imdb_rating) FROM movies)
ORDER BY worldwide_gross_usd DESC;

-- Q8: Year-over-year trend — average budget and gross per release year
SELECT release_year,
       COUNT(*) AS num_movies,
       ROUND(AVG(budget_usd)/1000000.0, 1) AS avg_budget_millions,
       ROUND(AVG(worldwide_gross_usd)/1000000.0, 1) AS avg_gross_millions
FROM movies
GROUP BY release_year
ORDER BY release_year;

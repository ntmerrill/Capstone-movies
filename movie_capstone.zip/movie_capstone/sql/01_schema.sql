-- ============================================================
-- Movie Box Office & Ratings Database — Schema
-- ============================================================
PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS genres;
DROP TABLE IF EXISTS studios;

CREATE TABLE genres (
    genre_id    INTEGER PRIMARY KEY,
    genre_name  TEXT NOT NULL UNIQUE
);

CREATE TABLE studios (
    studio_name     TEXT PRIMARY KEY,
    parent_company  TEXT NOT NULL,
    country         TEXT NOT NULL,
    founded_year    INTEGER NOT NULL CHECK (founded_year >= 1900)
);

CREATE TABLE movies (
    movie_id              INTEGER PRIMARY KEY,
    title                 TEXT NOT NULL,
    release_year          INTEGER NOT NULL CHECK (release_year BETWEEN 1990 AND 2026),
    studio_name           TEXT NOT NULL REFERENCES studios(studio_name),
    genre_id              INTEGER NOT NULL REFERENCES genres(genre_id),
    director              TEXT NOT NULL,
    runtime_min           INTEGER NOT NULL CHECK (runtime_min > 0),
    budget_usd            INTEGER NOT NULL CHECK (budget_usd >= 0),
    domestic_gross_usd    INTEGER NOT NULL CHECK (domestic_gross_usd >= 0),
    worldwide_gross_usd   INTEGER NOT NULL CHECK (worldwide_gross_usd >= 0),
    imdb_rating           REAL NOT NULL CHECK (imdb_rating BETWEEN 0 AND 10),
    rt_score              INTEGER NOT NULL CHECK (rt_score BETWEEN 0 AND 100),
    mpaa_rating           TEXT NOT NULL CHECK (mpaa_rating IN ('G','PG','PG-13','R','NC-17')),
    UNIQUE (title, release_year)
);

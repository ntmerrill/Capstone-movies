import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

conn = sqlite3.connect('/home/claude/movie_capstone/movies.db')
plt.rcParams['font.family'] = 'DejaVu Sans'

# ---------- Chart 1: ROI by genre ----------
df1 = pd.read_sql_query("""
SELECT g.genre_name,
       AVG(CAST(m.worldwide_gross_usd AS REAL) / m.budget_usd) AS roi
FROM movies m JOIN genres g ON m.genre_id = g.genre_id
GROUP BY g.genre_name
HAVING COUNT(*) >= 3
ORDER BY roi DESC
""", conn)

fig, ax = plt.subplots(figsize=(9, 5.5))
colors = plt.cm.viridis_r([i/len(df1) for i in range(len(df1))])
ax.barh(df1['genre_name'], df1['roi'], color=colors)
ax.set_xlabel('Average Return on Budget (×)')
ax.set_title('Return on Investment by Genre\n(Worldwide Gross ÷ Budget)', fontsize=13, fontweight='bold')
ax.invert_yaxis()
for i, v in enumerate(df1['roi']):
    ax.text(v + 0.15, i, f'{v:.1f}×', va='center', fontsize=9)
plt.tight_layout()
plt.savefig('/home/claude/movie_capstone/visuals/01_roi_by_genre.png', dpi=150)
plt.close()

# ---------- Chart 2: Studio total gross ----------
df2 = pd.read_sql_query("""
SELECT s.studio_name, SUM(m.worldwide_gross_usd)/1e9 AS gross_b, AVG(m.rt_score) AS rt
FROM movies m JOIN studios s ON m.studio_name = s.studio_name
GROUP BY s.studio_name
HAVING COUNT(*) >= 2
ORDER BY gross_b DESC
""", conn)

fig, ax = plt.subplots(figsize=(9, 6))
bars = ax.bar(df2['studio_name'], df2['gross_b'], color='#3b6e8f')
ax.set_ylabel('Total Worldwide Gross ($ Billions)')
ax.set_title('Total Box Office Gross by Studio (Sampled Films)', fontsize=13, fontweight='bold')
plt.xticks(rotation=45, ha='right')
for b, v in zip(bars, df2['gross_b']):
    ax.text(b.get_x() + b.get_width()/2, v + 0.2, f'${v:.1f}B', ha='center', fontsize=8)
plt.tight_layout()
plt.savefig('/home/claude/movie_capstone/visuals/02_studio_gross.png', dpi=150)
plt.close()

# ---------- Chart 3: Budget tier vs critical reception ----------
df3 = pd.read_sql_query("""
SELECT CASE WHEN budget_usd < 30000000 THEN 'Low (<$30M)'
            WHEN budget_usd < 150000000 THEN 'Mid ($30-150M)'
            ELSE 'High (>$150M)' END AS tier,
       AVG(imdb_rating) AS avg_imdb, AVG(rt_score) AS avg_rt
FROM movies GROUP BY tier
""", conn)
order = ['Low (<$30M)', 'Mid ($30-150M)', 'High (>$150M)']
df3['tier'] = pd.Categorical(df3['tier'], categories=order, ordered=True)
df3 = df3.sort_values('tier')

fig, ax = plt.subplots(figsize=(8, 5.5))
x = range(len(df3))
width = 0.35
ax.bar([i - width/2 for i in x], df3['avg_imdb']*10, width, label='IMDb Rating (×10)', color='#e07a5f')
ax.bar([i + width/2 for i in x], df3['avg_rt'], width, label='Rotten Tomatoes Score', color='#81b29a')
ax.set_xticks(list(x))
ax.set_xticklabels(df3['tier'])
ax.set_ylabel('Score')
ax.set_title('Budget Tier vs. Critical Reception', fontsize=13, fontweight='bold')
ax.legend()
plt.tight_layout()
plt.savefig('/home/claude/movie_capstone/visuals/03_budget_vs_critics.png', dpi=150)
plt.close()

# ---------- Chart 4: Budget vs Worldwide Gross scatter ----------
df4 = pd.read_sql_query("""
SELECT title, budget_usd/1e6 AS budget_m, worldwide_gross_usd/1e6 AS gross_m, imdb_rating
FROM movies
""", conn)

fig, ax = plt.subplots(figsize=(9, 6.5))
sc = ax.scatter(df4['budget_m'], df4['gross_m'], c=df4['imdb_rating'], cmap='RdYlGn', s=45, alpha=0.8, edgecolor='gray', linewidth=0.3)
ax.set_xlabel('Budget ($ Millions)')
ax.set_ylabel('Worldwide Gross ($ Millions)')
ax.set_title('Budget vs. Worldwide Gross\n(color = IMDb rating)', fontsize=13, fontweight='bold')
cbar = plt.colorbar(sc)
cbar.set_label('IMDb Rating')
# break-even line
import numpy as np
xline = np.linspace(0, df4['budget_m'].max(), 100)
ax.plot(xline, xline*2.5, '--', color='gray', alpha=0.6, label='2.5× budget (typical break-even incl. marketing)')
ax.legend(loc='upper left', fontsize=8)
plt.tight_layout()
plt.savefig('/home/claude/movie_capstone/visuals/04_budget_vs_gross_scatter.png', dpi=150)
plt.close()

# ---------- Chart 5: Year over year trend ----------
df5 = pd.read_sql_query("""
SELECT release_year, AVG(budget_usd)/1e6 AS avg_budget_m, AVG(worldwide_gross_usd)/1e6 AS avg_gross_m
FROM movies GROUP BY release_year ORDER BY release_year
""", conn)

fig, ax = plt.subplots(figsize=(10, 5.5))
ax.plot(df5['release_year'], df5['avg_gross_m'], marker='o', label='Avg Worldwide Gross', color='#3d5a80', linewidth=2)
ax.plot(df5['release_year'], df5['avg_budget_m'], marker='s', label='Avg Budget', color='#ee6c4d', linewidth=2)
ax.set_xlabel('Release Year')
ax.set_ylabel('$ Millions')
ax.set_title('Average Budget vs. Worldwide Gross by Release Year', fontsize=13, fontweight='bold')
ax.legend()
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig('/home/claude/movie_capstone/visuals/05_yearly_trend.png', dpi=150)
plt.close()

# ---------- Chart 6: MPAA rating breakdown ----------
df6 = pd.read_sql_query("""
SELECT mpaa_rating, AVG(worldwide_gross_usd)/1e6 AS avg_gross_m, COUNT(*) AS n
FROM movies GROUP BY mpaa_rating ORDER BY avg_gross_m DESC
""", conn)

fig, ax = plt.subplots(figsize=(8, 5.5))
bars = ax.bar(df6['mpaa_rating'], df6['avg_gross_m'], color=['#577590','#43aa8b','#f9c74f','#f3722c'])
ax.set_ylabel('Average Worldwide Gross ($ Millions)')
ax.set_title('Average Worldwide Gross by MPAA Rating', fontsize=13, fontweight='bold')
for b, v, n in zip(bars, df6['avg_gross_m'], df6['n']):
    ax.text(b.get_x()+b.get_width()/2, v+20, f'${v:.0f}M\n(n={n})', ha='center', fontsize=9)
plt.tight_layout()
plt.savefig('/home/claude/movie_capstone/visuals/06_mpaa_rating_gross.png', dpi=150)
plt.close()

conn.close()
print("All 6 charts saved successfully.")
